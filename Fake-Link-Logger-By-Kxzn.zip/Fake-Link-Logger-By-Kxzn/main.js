var request = new XMLHttpRequest();
request.open("POST", "Your Webhook Here");
request.setRequestHeader('Content-type', 'application/json');

var myEmbed = {
  title: "Your Title Here",
  description: "@everyone Here Is Your Link [https://upload.wikimedia.org/wikipedia/commons/thumb/b/b6/Image_created_with_a_mobile_phone.png/800px-Image_created_with_a_mobile_phone.png](https://n00bhub.000webhostapp.com/FAKE)",
  color: hexToDecimal("#0000FF")
}

var params = {
  username: "Kzxn",
  embeds: [ myEmbed ]
}

request.send(JSON.stringify(params));


function hexToDecimal(hex) {
  return parseInt(hex.replace("#",""), 16)
}